#pragma once 
#include <vector>

#include "Config.hpp"

#include "Token.hpp"


struct Visitor;
struct Expr;
class Environment;

enum StmtType
{
    S_NONE = 0,
    BLOCK,
    EXPRESSION,
    DECLARATION,
    IF,
    WHILE,
    FOR,
    DO,
    SWITCH,
    RETURN,
    BREAK,
    CONTINUE,
    PRINT,
    FUNCTION,
    PROGRAM,
    S_COUNT,
};

class Stmt
{
public:
    Stmt()  {}
    virtual ~Stmt() {}
    virtual u8 visit( Visitor &v) = 0;

    StmtType type{StmtType::S_NONE};

    std::string toString();
};


class BlockStmt : public Stmt
{
public:
    BlockStmt() : Stmt() { type = StmtType::BLOCK; }

    ~BlockStmt();

    u8 visit( Visitor &v) override;

    std::vector<Stmt *> statements;
};


class ExpressionStmt : public Stmt
{
public:
    ExpressionStmt() : Stmt() { type = StmtType::EXPRESSION; }

    u8 visit( Visitor &v) override;

    Expr *expression;
};


struct ElifStmt
{
    Expr *condition;
    Stmt *then_branch;
};

class IFStmt : public Stmt
{
public:
    IFStmt();

    u8 visit( Visitor &v) override;

    Expr *condition;
    Stmt *then_branch;
    Stmt *else_branch;

    std::vector<ElifStmt*> elifBranch;

};

struct CaseStmt 
{
    Expr *condition;
    Stmt *body;
};

class SwitchStmt : public Stmt
{
public:
    SwitchStmt() : Stmt() { type = StmtType::SWITCH; }

    u8 visit( Visitor &v) override;

    Expr *condition;
    std::vector<CaseStmt*> cases;
    Stmt *defaultBranch;
};

class WhileStmt : public Stmt
{
public:
    WhileStmt() : Stmt() { type = StmtType::WHILE; }

    u8 visit( Visitor &v) override;

    Expr *condition;
    Stmt *body;

};

class DoStmt : public Stmt
{
public:
    DoStmt() : Stmt() { type = StmtType::DO; }

    u8 visit( Visitor &v) override;

    Expr *condition;
    Stmt *body;
};


class ForStmt : public Stmt
{
public:
    ForStmt() : Stmt() { type = StmtType::FOR; }

    u8 visit( Visitor &v) override;

    Stmt *initializer;
    Expr *condition;
    Expr *increment;
    Stmt *body;
};

class PrintStmt : public Stmt
{
public:
    PrintStmt() : Stmt() { type = StmtType::PRINT; }
    u8 visit( Visitor &v) override;

    Expr *expression;
};

class Declaration : public Stmt
{
public:
    Declaration() : Stmt() { type = StmtType::DECLARATION; }
    u8 visit( Visitor &v) override;
    std::vector<Token> names;
    bool is_initialized = false;
    Expr *initializer;
};

class ReturnStmt : public Stmt
{
public:
    ReturnStmt() : Stmt() { type = StmtType::RETURN; }
    u8 visit( Visitor &v) override;

    Expr *value;

};


class BreakStmt : public Stmt
{
public:
    BreakStmt() : Stmt() { type = StmtType::BREAK; }
    u8 visit( Visitor &v) override;
};


class ContinueStmt : public Stmt
{
public:
    ContinueStmt() : Stmt() { type = StmtType::CONTINUE; }
    u8 visit( Visitor &v) override;
};


class FunctionStmt : public Stmt
{
public:
    FunctionStmt() : Stmt() { type = StmtType::FUNCTION; }
    u8 visit( Visitor &v) override;
    std::vector<std::string> args;
    Token name;
    Stmt *body;

};




class Program : public Stmt
{
public:
    Program() : Stmt() { type = StmtType::PROGRAM; }

    u8 visit( Visitor &v) override;

    std::vector<Stmt *> statements;
};