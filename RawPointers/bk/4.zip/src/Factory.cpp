#include "pch.h"
#include "Arena.hpp"
#include "Factory.hpp"
#include "Interpreter.hpp"
#include "Utils.hpp"


Factory::Factory()
{
}

Factory::~Factory()
{
}

Factory &Factory::as()
{
    static Factory factory;
    return factory;
}

static float memoryInMB(size_t bytes)
{
    return static_cast<float>(bytes) / (1024.0f * 1024.0f);
}

static float memoryInKB(size_t bytes)
{
    return static_cast<float>(bytes) / 1024.0f;
}

struct AllocationInfo
{
	u32 size;
	std::string file;
	u32 line;
};

static std::unordered_map<void *, AllocationInfo> g_allocations;
static bool g_debugMode = false;

void *Malloc(u32 size, const char *file, u32 line)
{
    void *mem = ArenaAlloc(size); // Factory::as().arena.Allocate(size);
    if (g_debugMode && mem != nullptr)
	{
		g_allocations[mem] = {size, file, line};
	}
	return mem;
}

void Free(void *mem, u32 size)
{
	if (g_debugMode && mem != nullptr)
	{
		auto it = g_allocations.find(mem);
		if (it != g_allocations.end())
		{
			g_allocations.erase(it);
		}
	}

    ArenaFree(mem);
    //Factory::as().arena.Free(mem, size);
}
void ReportMemoryLeaks()
{
	if (!g_debugMode)
		return;

	if (!g_allocations.empty())
	{
		WARNING("Memory Leaks Detected:");
		for (const auto &entry : g_allocations)
		{
			WARNING("Leaked %d bytes at %p, allocated at %s:%d",
				   entry.second.size,
				   entry.first,
				   entry.second.file.c_str(),
				   entry.second.line);
		}
	}
	else
	{
		INFO("No memory leaks detected.\n");
	}
}

static const  char* memoryIn(size_t bytes)
{
    if (bytes >= 1.0e6)
    {
        return FormatText("%.2f MB", memoryInMB(bytes));
    }
    else if (bytes >= 1.0e3)
    {
        return FormatText("%.2f KB", memoryInKB(bytes));
    }
    return FormatText("%zu bytes", bytes);
}

void Factory::clear()
{
    ReportMemoryLeaks();
    INFO("Arena cleared %s",memoryIn(arena.size()));
}

Environment *Factory::make_environment( Environment *parent)
{
  
  Environment *env = new Environment(parent);
  return env;
}



void Factory::free_environment(Environment *expr)
{

    delete expr;
}


BinaryExpr *Factory::make_binary()
{
   BinaryExpr *expr = new BinaryExpr();
   return expr;
}




void Factory::free_binary(BinaryExpr *expr)
{

   // delete_expression(expr->left);
    delete_expression(expr->right);
    delete expr;

}

UnaryExpr *Factory::make_unary()
{
   UnaryExpr *expr = new UnaryExpr();
   return expr;
}

void Factory::free_unary(UnaryExpr *expr)
{
  //  delete_expression(expr->right);
    
    delete expr;
}

LogicalExpr *Factory::make_logical()
{
    LogicalExpr *expr = new LogicalExpr();
    return expr;
}

void Factory::free_logical(LogicalExpr *expr)
{

    delete_expression(expr->left);
    delete_expression(expr->right);
   
    delete expr;
}

GroupingExpr *Factory::make_grouping()
{
    GroupingExpr *expr = new GroupingExpr();
    return expr;
}

void Factory::free_grouping(GroupingExpr *expr)
{

    delete_expression(expr->expr);

    delete expr;
}

NumberLiteral *Factory::make_number()
{
    NumberLiteral *expr = new NumberLiteral();
    return expr;
}

void Factory::free_number(NumberLiteral *expr)
{

    delete expr;
}

StringLiteral *Factory::make_string()
{
    StringLiteral *expr = new StringLiteral();
    return expr;
}

void Factory::free_string(StringLiteral *expr)
{

    delete expr;
}

Literal *Factory::make_literal()
{
    Literal *expr = new Literal();
    return expr;
}

void Factory::free_literal(Literal *expr)
{

    delete expr;
}

ArrayLiteral *Factory::create_array()
{
    ArrayLiteral *al = new ArrayLiteral();
    return al;
}

void Factory::delete_array(ArrayLiteral *expr)
{

    delete expr;
}

MapLiteral *Factory::create_map()
{
    MapLiteral *al = new MapLiteral();
    return al;
}

void Factory::delete_map(MapLiteral *expr)
{

    delete expr;
}

NowExpr *Factory::make_now()
{
    NowExpr *expr = new NowExpr();
    return expr;
}

void Factory::free_now(NowExpr *expr)
{

    delete expr;
}

PrintStmt *Factory::make_print()
{
    PrintStmt *expr = new PrintStmt();
    return expr;
}

void Factory::free_print(PrintStmt *expr)
{

    delete expr;
}

ExpressionStmt *Factory::make_expression()
{
    ExpressionStmt *expr = new ExpressionStmt();
    return expr;
}

void Factory::free_expression(ExpressionStmt *expr)
{
       // INFO("Free expression statmnent");
        delete_expression(expr->expression);

        delete expr;

}

BlockStmt *Factory::make_block()
{
    BlockStmt *expr = new BlockStmt();
    return expr;
}

void Factory::free_block(BlockStmt *expr)
{
   // INFO("Free block");
    for (auto &stmt : expr->statements)
    {
       delete_statement(stmt);
    }

    delete expr;
}

Program *Factory::make_program()
{
    Program *expr = new Program();
    return expr;
}

void Factory::free_program(Program *expr)
{
//
    INFO("Free program");
    for (auto &stmt : expr->statements)
    {
        delete_statement(stmt);
    }

    delete expr;
}

FunctionStmt *Factory::make_function()
{
    FunctionStmt *expr = new FunctionStmt();
    return expr;
}

void Factory::free_function(FunctionStmt *expr)
{

  //  INFO("Free function");
    delete_statement(expr->body);

    delete expr;
}

Function *Factory::createFunction()
{
    Function *expr = new Function();
    return expr;
}

void Factory::deleteFunction(Function *node)
{

    delete node;
}

StructLiteral *Factory::createStruct()
{
   StructLiteral *expr = new StructLiteral();
   return expr;
}

void Factory::deleteStruct(StructLiteral *node)
{
//    WARNING("Deleting struct: %s", node->name.c_str());

    delete node;
}

ClassLiteral *Factory::createClass()
{
    ClassLiteral *expr = new ClassLiteral();
    return expr;
}

void Factory::deleteClass(ClassLiteral *node)
{

    delete node;
}

Native *Factory::createNative()
{
    Native *expr = new Native();
    return expr;
}

void Factory::deleteNative(Native *node)
{

    delete node;
}

CallExpr *Factory::make_call()
{
    CallExpr *expr = new CallExpr();
    return expr;
}

void Factory::free_call(CallExpr *expr)
{
    for (auto &arg : expr->args)
    {
       delete_expression(arg);
    }

    delete expr;
}

GetExpr *Factory::make_get()
{
     GetExpr *expr = new GetExpr();
     return expr;
}

void Factory::free_get(GetExpr *expr)
{

    delete expr;
}

SetExpr *Factory::make_set()
{
    SetExpr *expr = new SetExpr();
    return expr;
}

void Factory::free_set(SetExpr *expr)
{

    delete expr;
}

GetDefinitionExpr *Factory::make_get_definition()
{
    GetDefinitionExpr *expr = new GetDefinitionExpr();
    return expr;
}

void Factory::free_get_definition(GetDefinitionExpr *expr)
{

    delete expr;
}

void Factory::delete_statement(Stmt *expr)
{
    
    if (expr)
    {
        if (expr->type == StmtType::DECLARATION)
        {
          //  WARNING("Free declaration");
            free_declaration(static_cast<Declaration*>(expr));
        } else if (expr->type == StmtType::PRINT)
        {
           // WARNING("Free print");
            free_print(static_cast<PrintStmt*>(expr));
        } else if (expr->type == StmtType::EXPRESSION)
        {
          //  WARNING("Free expression");
           // free_expression(static_cast<ExpressionStmt*>(expr));
        } else if (expr->type == StmtType::BLOCK)
        {
          //  WARNING("Free block");
            free_block(static_cast<BlockStmt*>(expr));

        } else if (expr->type == StmtType::IF)
        {
           // WARNING("Free if");
            free_if(static_cast<IFStmt*>(expr));
        } else if (expr->type == StmtType::WHILE)
        {
            free_while(static_cast<WhileStmt*>(expr));
        }   else if (expr->type == StmtType::BREAK)
        {
           // WARNING("Free break");
            free_break(static_cast<BreakStmt*>(expr));            
        }  else if (expr->type == StmtType::RETURN)
        {
           // WARNING("Free return");
            free_return(static_cast<ReturnStmt*>(expr));
        } else if (expr->type == StmtType::CONTINUE)
        {
          //  WARNING("Free continue");
            free_continue(static_cast<ContinueStmt*>(expr));
        } 
        else if (expr->type == StmtType::FOR)
        {
          //  WARNING("Free for");
            free_for(static_cast<ForStmt*>(expr));
        } else if (expr->type == StmtType::SWITCH)
        {
          //  WARNING("Free switch");
            free_switch(static_cast<SwitchStmt*>(expr));
        } else if (expr->type == StmtType::DO)
        {
           // WARNING("Free do");
            free_do(static_cast<DoStmt*>(expr));
        } else if (expr->type == StmtType::FUNCTION)
        {
           // WARNING("Free function");
            free_function(static_cast<FunctionStmt*>(expr));
        } else if (expr->type == StmtType::CLASS)
        {
           // WARNING("Free class");
            free_class(static_cast<ClassStmt*>(expr));
        } else if (expr->type == StmtType::STRUCT)
        {

            free_struct(static_cast<StructStmt*>(expr));
        } else if (expr->type == StmtType::ARRAY)
        {
            free_array(static_cast<ArrayStmt*>(expr));
        } else if (expr->type == StmtType::MAP)
        {
            free_map(static_cast<MapStmt*>(expr));
        }
        
        else 
        {
            INFO("Unknown statement type %d",(  int)expr->type);
        }
    }
}

void Factory::delete_expression(Expr *expr)
{
    return;
    if (expr)
    {
        if (expr->type == ExprType::BINARY)
        {
          //  free_binary(static_cast<BinaryExpr*>(expr));
        } else if (expr->type == ExprType::UNARY)
        {
            //free_unary(static_cast<UnaryExpr*>(expr));
        } else if (expr->type == ExprType::LOGICAL)
        {
            //free_logical(static_cast<LogicalExpr*>(expr));
        } else if (expr->type == ExprType::GROUPING)
        {
           // free_grouping(static_cast<GroupingExpr*>(expr));
        } else if (expr->type == ExprType::LITERAL)
        {
            free_literal(static_cast<Literal*>(expr));
        } else if (expr->type == ExprType::L_NUMBER)
        {
            free_number(static_cast<NumberLiteral*>(expr));
        } else if (expr->type == ExprType::L_STRING)
        {
            free_string(static_cast<StringLiteral*>(expr));
        } else if (expr->type == ExprType::NOW)
        {
           // free_now(static_cast<NowExpr*>(expr));
        } else if (expr->type == ExprType::L_STRUCT)
        {
            deleteStruct(static_cast<StructLiteral*>(expr));
        } else if (expr->type == ExprType::VARIABLE)
        {
            free_variable(static_cast<Variable*>(expr));
        } else if (expr->type == ExprType::GET)
        {
            free_get(static_cast<GetExpr*>(expr));
        } else if (expr->type == ExprType::GET_DEF)
        {
            free_get_definition(static_cast<GetDefinitionExpr*>(expr));
        } 
        else if (expr->type == ExprType::SET)
        {
            free_set(static_cast<SetExpr*>(expr));
        }  else if (expr->type == ExprType::CALL)
        {
          //  free_call(static_cast<CallExpr*>(expr));
        }  else if (expr->type == ExprType::ASSIGN)
        {
            free_assign(static_cast<Assign*>(expr));
        } else if (expr->type == ExprType::L_FUNCTION)
        {
           // free_function(static_cast<Function*>(expr));
        }
        else 
        {
            INFO("Unknown expression type %d",(  int)expr->type);
        }
    }
}

Declaration *Factory::make_declaration()
{
    
    Declaration *p = new Declaration();
    return p;
}

void Factory::free_declaration(Declaration *expr)
{
   // INFO("Free  declaration");
    delete expr;
}

Variable *Factory::make_variable()
{
     Variable *p = new Variable();
     return p;
}

void Factory::free_variable(Variable *expr)
{
   // INFO("Free  variable");
    delete expr;
}

Assign *Factory::make_assign()
{
     Assign *p = new Assign();
     return p;
}

void Factory::free_assign(Assign *expr)
{
   // INFO("Free  assign");
    //delete_expression(expr->value);
    delete expr;
}

IFStmt *Factory::make_if()
{
     IFStmt *p = new IFStmt();
     return p;
}

void Factory::free_if(IFStmt *expr)
{
   // INFO("Free  if");
    delete_expression(expr->condition);
    delete_statement(expr->then_branch);
    delete_statement(expr->else_branch);
    for (auto &elif : expr->elifBranch)
    {
         free_elif(elif);
    }
    delete expr;
}

ElifStmt *Factory::make_elif()
{
    ElifStmt *p = new ElifStmt();
    return p;
}

void Factory::free_elif(ElifStmt *expr)
{
 //   INFO("Free  elif");
    delete_expression(expr->condition);
    delete_statement(expr->then_branch);
    delete expr;
}

WhileStmt *Factory::make_while()
{
    WhileStmt *p = new WhileStmt();
    return p;
}

void Factory::free_while(WhileStmt *expr)
{
   // INFO("Free  while");
    delete_expression(expr->condition);
    delete_statement(expr->body);
    delete expr;
}

DoStmt *Factory::make_do()
{
    DoStmt *p = new DoStmt();
    return p;
}

void Factory::free_do(DoStmt *expr)
{
  //  INFO("Free  do");
    delete_expression(expr->condition);
    delete_statement(expr->body);
    delete expr;
}

ForStmt *Factory::make_for()
{
    ForStmt *p = new ForStmt();
    return p;
}

void Factory::free_for(ForStmt *expr)
{
   // INFO("Free  for");
    delete_statement(expr->initializer);
    delete_expression(expr->condition);
    delete_expression(expr->increment);
    delete_statement(expr->body);



    delete expr;
}

ReturnStmt *Factory::make_return()
{
    ReturnStmt *p = new ReturnStmt();
    return p;
}

void Factory::free_return(ReturnStmt *expr)
{
   // delete_expression(expr->value);
    delete expr;
}

BreakStmt *Factory::make_break()
{
    BreakStmt *p = new BreakStmt();
    return p;
    
}

void Factory::free_break(BreakStmt *expr)
{

    delete expr;
}

ContinueStmt *Factory::make_continue()
{
    ContinueStmt *p = new ContinueStmt();
    return p;
}

void Factory::free_continue(ContinueStmt *expr)
{

    delete expr;
}

CaseStmt *Factory::make_case()
{
    CaseStmt *p = new CaseStmt();
    return p;
}

void Factory::free_case(CaseStmt *expr)
{
   /// INFO("Free  case");
    delete_expression(expr->condition);
    delete_statement(expr->body);
    

    delete expr;
}

SwitchStmt *Factory::make_switch()
{
    SwitchStmt *p = new SwitchStmt();
    return p;
}

void Factory::free_switch(SwitchStmt *expr)
{
   // INFO("Free  switch");
    for (auto &caseStmt : expr->cases)
    {
        free_case(caseStmt);
    }
    delete_expression(expr->condition);
    if (expr->defaultBranch!=nullptr)
        delete_statement(expr->defaultBranch);
    

    delete expr;
}

StructStmt *Factory::make_struct()
{
    StructStmt *p = new StructStmt();
    return p;
}

void Factory::free_struct(StructStmt *expr)
{
   // INFO("Free  struct declaration %s", expr->name.lexeme.c_str());
    expr->values.clear();
    expr->fields.clear();

    delete expr;
}

ClassStmt *Factory::make_class()
{
    ClassStmt *p = new ClassStmt();
    return p;
}

void Factory::free_class(ClassStmt *expr)
{
    INFO("Free  class");
    for (auto &field : expr->fields)
    {
      //  delete_expression(field);
    }
    for (auto &method : expr->methods)
    {
       // free_function(method);
    }

    delete expr;
}

ArrayStmt *Factory::make_array()
{
    ArrayStmt *p = new ArrayStmt();
    return p;
}

void Factory::free_array(ArrayStmt *expr)
{

    delete expr;
}

MapStmt *Factory::make_map()
{
    MapStmt *p = new MapStmt();
    return p;
}

void Factory::free_map(MapStmt *expr)
{

    delete expr;
}
