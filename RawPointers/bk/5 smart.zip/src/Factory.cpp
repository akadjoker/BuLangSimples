#include "pch.h"
#include "Arena.hpp"
#include "Factory.hpp"
#include "Interpreter.hpp"
#include "Utils.hpp"


Factory::Factory()
{
}

Factory::~Factory()
{
}

Factory &Factory::as()
{
    static Factory factory;
    return factory;
}

static float memoryInMB(size_t bytes)
{
    return static_cast<float>(bytes) / (1024.0f * 1024.0f);
}

static float memoryInKB(size_t bytes)
{
    return static_cast<float>(bytes) / 1024.0f;
}

struct AllocationInfo
{
	u32 size;
	std::string file;
	u32 line;
};

static std::unordered_map<void *, AllocationInfo> g_allocations;
static bool g_debugMode = false;

void *Malloc(u32 size, const char *file, u32 line)
{
    void *mem = ArenaAlloc(size); // Factory::as().arena.Allocate(size);
    if (g_debugMode && mem != nullptr)
	{
		g_allocations[mem] = {size, file, line};
	}
	return mem;
}

void Free(void *mem, u32 size)
{
	if (g_debugMode && mem != nullptr)
	{
		auto it = g_allocations.find(mem);
		if (it != g_allocations.end())
		{
			g_allocations.erase(it);
		}
	}

    ArenaFree(mem);
    //Factory::as().arena.Free(mem, size);
}
void ReportMemoryLeaks()
{
	if (!g_debugMode)
		return;

	if (!g_allocations.empty())
	{
		WARNING("Memory Leaks Detected:");
		for (const auto &entry : g_allocations)
		{
			WARNING("Leaked %d bytes at %p, allocated at %s:%d",
				   entry.second.size,
				   entry.first,
				   entry.second.file.c_str(),
				   entry.second.line);
		}
	}
	else
	{
		INFO("No memory leaks detected.\n");
	}
}

static const  char* memoryIn(size_t bytes)
{
    if (bytes >= 1.0e6)
    {
        return FormatText("%.2f MB", memoryInMB(bytes));
    }
    else if (bytes >= 1.0e3)
    {
        return FormatText("%.2f KB", memoryInKB(bytes));
    }
    return FormatText("%zu bytes", bytes);
}

void Factory::clear()
{
    ReportMemoryLeaks();
    INFO("Arena cleared %s",memoryIn(arena.size()));
}

Environment *Factory::make_environment( Environment *parent)
{
  
  Environment *env = new Environment(parent);
  return env;
}



void Factory::free_environment(Environment *expr)
{

    delete expr;
}
