
#include "pch.h" 
#include "Expr.hpp" 
#include "Interpreter.hpp"
#include "Utils.hpp"

std::shared_ptr<Expr> EmptyExpr::accept(Visitor &v)
{
    return v.visit_empty_expression(this);
}



std::shared_ptr<Expr> BinaryExpr::accept(Visitor &v)
{
    return v.visit_binary(this);
}



std::shared_ptr<Expr> UnaryExpr::accept(Visitor &v)
{
    return v.visit_unary(this);
}



std::shared_ptr<Expr> GroupingExpr::accept(Visitor &v)
{
    return v.visit_grouping(this);
}



std::shared_ptr<Expr> LogicalExpr::accept(Visitor &v)
{
    return v.visit_logical(this);
}



std::shared_ptr<Expr> NumberLiteral::accept(Visitor &v)
{
    return v.visit_number_literal(this);
}

void NumberLiteral::print()
{
    PRINT("value: %f", value);
}

std::shared_ptr<Expr> StringLiteral::accept(Visitor &v)
{
    return  v.visit_string_literal(this);
}

void StringLiteral::print()
{
    PRINT("value: %s", value.c_str());
}

std::shared_ptr<Expr> NowExpr::accept(Visitor &v)
{
    return v.visit_now_expression(this);
}

std::shared_ptr<Expr> Variable::accept(Visitor &v)
{
    return  v.visit_variable(this);
}

std::shared_ptr<Expr> Assign::accept(Visitor &v)
{
    return  v.visit_assign(this);
}

std::shared_ptr<Expr> Literal::accept(Visitor &v)
{
    return  v.visit_literal(this);
}

void Literal::print()
{
    PRINT("nil");
}

std::string Expr::toString()
{
   switch (type)
   {
       case ExprType::E_NONE: return "NONE";
       case ExprType::L_NUMBER: return "NUMBER";
       case ExprType::L_STRING: return "STRING";
       case ExprType::L_FUNCTION: return "FUNCTION";
       case ExprType::L_CLASS: return "CLASS";
       case ExprType::L_STRUCT: return "STRUCT";
       case ExprType::L_ARRAY: return "ARRAY";
       case ExprType::L_MAP: return "MAP";
       case ExprType::L_NATIVE: return "NATIVE";
       case ExprType::LITERAL: return "LITERAL";
       case ExprType::BINARY: return "BINARY";
       case ExprType::UNARY: return "UNARY";
       case ExprType::GROUPING: return "GROUPING";
       case ExprType::LOGICAL: return "LOGICAL";
       case ExprType::NOW: return "NOW";
       case ExprType::VARIABLE: return "VARIABLE";
       case ExprType::EMPTY_EXPR: return "EMPTY_EXPR";
       case ExprType::ASSIGN: return "ASSIGN";
       case ExprType::CALL: return "CALL";
       case ExprType::GET: return "GET";
       case ExprType::SET: return "SET";
       case ExprType::GET_DEF: return "GET_DEF";
       
       default: return "UNKNOWN";
       
   }

   return "UNKNOWN";
}

std::shared_ptr<Expr> CallExpr::accept(Visitor &v)
{
    return v.visit_call(this);
}

std::shared_ptr<Expr> GetExpr::accept(Visitor &v)
{
    return v.visit_get(this);
}

std::shared_ptr<Expr> SetExpr::accept(Visitor &v)
{
    return v.visit_set(this);
}

std::shared_ptr<Expr> GetDefinitionExpr::accept(Visitor &v)
{
    return v.visit_get_definition(this);
}
