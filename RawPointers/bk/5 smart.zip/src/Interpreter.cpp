#include "pch.h"

#include "Interpreter.hpp"
#include "Utils.hpp"
#include "Factory.hpp"


class BreakException : public std::runtime_error
{
public:
    explicit BreakException(std::string message) : std::runtime_error(message) {}
};

class ContinueException : public std::runtime_error
{
public:
    explicit ContinueException(std::string message) : std::runtime_error(message) {}
};



class ReturnException : public std::runtime_error
{
public:
    explicit ReturnException(std::shared_ptr<Expr> value) : std::runtime_error("return"), value(std::move(value)) {}
    std::shared_ptr<Expr> value {nullptr};
};


std::shared_ptr<Expr>  Compiler::visit(std::shared_ptr<Expr> expr )
{
    
      std::shared_ptr<Expr> result = expr->accept(*this);

      return result;
}

std::shared_ptr<Expr> Compiler::visit_assign(Assign *node)
{
    if (!node) return nullptr;
    std::shared_ptr<Expr> value = evaluate(node->value);


    Environment *environment = currentEnvironment();

    if (!environment->assign(node->name.lexeme, std::move(value)))
    {
      // throw FatalException("Undefined variable: '" + node->name.lexeme +"' at line  "+ std::to_string(node->name.line )+" or mixe types.");
    }

    return value;
}

std::shared_ptr<Expr> Compiler::evaluate(  std::shared_ptr<Expr> expr)
{
    if (!expr) return std::make_shared<EmptyExpr>();
    std::shared_ptr<Expr>  result = visit(expr);
    return result;
}


std::shared_ptr<Expr> Compiler::visit_call_native(CallExpr *node)
{
   // INFO("CALL: %s ",node->name.lexeme.c_str());
    interpreter->context->values.clear();
    interpreter->context->literals.clear();
    for (u32 i = 0; i < node->args.size(); i++)
    {
        std::shared_ptr<Expr> arg = evaluate(node->args[i]);
        interpreter->context->literals.push_back(std::move(arg));
    }
    std::shared_ptr<Expr> result;
  //  = interpreter->CallNativeFunction(node->name.lexeme, (int)node->args.size());
   // interpreter->context->literals.clear();
    return result;
}

std::shared_ptr<Expr> Compiler::visit_call(CallExpr *node)
{

    if (!node) return nullptr;


  

          
    std::shared_ptr<Expr> callee = evaluate(node->callee);
    
    std::shared_ptr<Expr> var = global->get(node->name.lexeme);
    if (var->type == ExprType::L_STRUCT)
    {
       // PRINT("CALL Struct: %s ", node->name.lexeme.c_str());
        return callee;
    }

    if (var->type == ExprType::L_NATIVE)
    {
        return visit_call_native(node);
    }

    //  INFO("CALL: %s %s", var->toString().c_str(),node->name.lexeme.c_str());

    if (var->type != ExprType::L_FUNCTION)
        return callee;

    Function *function = static_cast<Function *>(callee.get());

    if (function->arity != node->args.size())
    {
        throw FatalException("Incorrect number of arguments in call to '" + node->name.lexeme +"' at line "+ std::to_string(node->name.line )+ " expected " + std::to_string(function->arity) + " but got " + std::to_string(node->args.size()));
    }

    enterBlock();
    Environment *environment = currentEnvironment();


    for (u32 i = 0; i < node->args.size(); i++)
    {

        std::shared_ptr<Expr> arg = evaluate(node->args[i]);
        environment->define(function->args[i], std::move(arg));
    }

    std::shared_ptr<Expr> result = nullptr;
    try  
    {
        BlockStmt *body = static_cast<BlockStmt *>(function->body.get());
        for (auto stmt : body->statements)
        {
            execute(stmt.get());
        }
        
    }
    catch (ReturnException &e)
    {
        result = std::move(e.value);
       
    }  

    exitBlock();

    if (result == nullptr)
    {
        result = std::make_shared<Literal>();
    }

    return result;
}




std::shared_ptr<Expr> Compiler::visit_get_definition(GetDefinitionExpr *node)
{

    //  INFO("GET Built int defenition: %s ", node->name.lexeme.c_str());
 

    std::shared_ptr<Expr> var     = evaluate(node->variable);
    if (!var) return std::make_shared<EmptyExpr>();

    

    if (var->type == ExprType::L_ARRAY)
    {
        ArrayLiteral *earray = static_cast<ArrayLiteral *>(var.get());
        std::shared_ptr<Expr> expr    = global->get(earray->name);
        if (!expr)  
        {
           ERROR("Array '%s' not found: " ,earray->name.c_str());
           return var;
        }


        ArrayLiteral *array = static_cast<ArrayLiteral *>(expr.get());
        if (node->name.lexeme == "push")
        {
                if (node->values.size() < 1)
                {
                    ERROR("Array 'push' requires 1 or more argument");
                    return var;
                }
                for (u32 i = 0; i < node->values.size(); i++)
                {
                     std::shared_ptr<Expr> value = evaluate(node->values[i]);
                     if (value->type == ExprType::L_NUMBER)
                     {
                        NumberLiteral *nl = static_cast<NumberLiteral *>(value.get());
                        std::shared_ptr<NumberLiteral> to =  std::make_shared<NumberLiteral>();
                        to->value = nl->value;
                        array->values.push_back(std::move(to));
                     } else if (value->type == ExprType::L_STRING)
                     {
                        StringLiteral *sl = static_cast<StringLiteral *>(value.get());
                        std::shared_ptr<StringLiteral> to =  std::make_shared<StringLiteral>();
                        to->value = sl->value;
                        array->values.push_back(std::move(to));
                     }
                      array->values.push_back(value);
                }
                array->print();

                return var;
  
        } else if (node->name.lexeme == "pop")
        {
                std::shared_ptr<Expr> value = array->values.back();
                array->values.pop_back();
            
                return value;
        } else if (node->name.lexeme == "length")
        {
            std::shared_ptr<NumberLiteral> result =  std::make_shared<NumberLiteral>();
            result->value = array->values.size();
            return result;
        }
        else if (node->name.lexeme == "at")
        {
            if (node->values.size() != 1)
            {
                ERROR("Array 'at' requires 1 argument");
                return var;
            }
            std::shared_ptr<Expr> value = evaluate(node->values[0]);
            if (!value) return var;
            if (value->type != ExprType::L_NUMBER)
            {
                ERROR("Array index must be a number");
                return var;
            }
            NumberLiteral *nl = static_cast<NumberLiteral *>(value.get());
            if (nl->value < 0 || nl->value >= array->values.size())
            {
                ERROR("Array index out of bounds");
                return var;
            }

            u32 index = (u32) static_cast<int>(nl->value);


            
           std::shared_ptr<Expr> result = array->values[index];
     

           return result;

    
        
        }else  if (node->name.lexeme == "set")
        {
            if (node->values.size() != 2)
            {
                ERROR("Array 'set' requires 2 arguments");
                return var;
            }
            std::shared_ptr<Expr> value = evaluate(node->values[0]);
            if (value->type != ExprType::L_NUMBER)
            {
                ERROR("Array index must be a number");
                return var;
            }
            NumberLiteral *nl = static_cast<NumberLiteral *>(value.get());
            if (nl->value < 0 || nl->value >= array->values.size())
            {
                ERROR("Array index out of bounds");
                return var;
            }

            int index = nl->value;
            return array->values[index];
        } 
        else 
        {
             WARNING("Unknown array function: %s", node->name.lexeme.c_str());
        }
    }



    return var;
}

std::shared_ptr<Expr> Compiler::visit_get(GetExpr *node)
{
  //  INFO("GET arg: %s", node->name.lexeme.c_str());
    std::shared_ptr<Expr> object = evaluate(node->object);
    if (object->type==ExprType::L_STRUCT)
    {
        StructLiteral *sl = static_cast<StructLiteral *>(object.get());

        if (sl->members.find(node->name.lexeme) != sl->members.end())
        {
            std::shared_ptr<Expr> value = sl->members[node->name.lexeme];
    
            return value;
        } else 
        {
            ERROR("Member not found: %s", node->name.lexeme.c_str());
        }
    } else if (object->type == ExprType::L_ARRAY)
    {
        WARNING("Array GET: %s", node->name.lexeme.c_str());
    }
    return  object;
}


std::shared_ptr<Expr> Compiler::visit_set(SetExpr *node)
{

   // INFO("SET arg: %s", node->name.lexeme.c_str());
    std::shared_ptr<Expr> object = evaluate(node->object);
    if (object->type==ExprType::L_STRUCT)
    {
        StructLiteral *sl = static_cast<StructLiteral *>(object.get());

        if (sl->members.find(node->name.lexeme) != sl->members.end())
        {

                 std::shared_ptr<Expr> value = evaluate(node->value);
                 sl->members[node->name.lexeme] = std::move(value);
        //         if (value->type == ExprType::L_NUMBER)
        //         {
        //             NumberLiteral *l =  std::make_shared<NumberLiteral>();
        //             l->value = static_cast<NumberLiteral *>(value)->value;
        //             sl->members[node->name.lexeme] = l;
        //         } else if (value->type == ExprType::L_STRING)
        //         {
        //             StringLiteral *l = Factory::as().make_string();
        //             l->value = static_cast<StringLiteral *>(value)->value;
        //             sl->members[node->name.lexeme] = l;
        //         } else
        //          {
        //             WARNING("TODO set value type: %s", value->toString().c_str());
        //         }
        }
    }    
    return object;
}

std::shared_ptr<Expr> Compiler::visit_now_expression(NowExpr *node)
{
    std::shared_ptr<NumberLiteral> result =  std::make_shared<NumberLiteral>();
    result->value = time_now();
    return result;
}



u8 Compiler::execute(Stmt *stmt)
{
    if (!stmt)
    {
        return 0;
    }
    return stmt->visit(*this);
}




void Compiler::enterBlock()
{

    Environment *env = Factory::as().make_environment(environmentStack.top());
    environmentStack.push(env);
}

Environment *Compiler::enterLocal( Environment *parent)
{

    Environment *env = Factory::as().make_environment(parent);
    environmentStack.push(env);
    return env;
}


void Compiler::exitBlock()
{
        if (environmentStack.size() > 1) 
        {
            Environment *env = environmentStack.top();
            Factory::as().free_environment(env);
            environmentStack.pop();
          
        }
}

Environment *Compiler::currentEnvironment()
{
    return environmentStack.top();
}

Environment *Compiler::globalEnvironment()
{
    return global;
}



void Compiler::clear()
{
    INFO("Compiler clear");
    interpreter = nullptr;
    while (environmentStack.size() > 0)
    {
        Environment *env = environmentStack.top();
        Factory::as().free_environment(env);
        environmentStack.pop();
    }
  
    
    arrays.clear();
    
    maps.clear();
   
    functionMap.clear();
    functions.clear();
}

u8 Compiler::visit_block_smt(BlockStmt *node)
{
    if (!node) return  0;


    enterBlock();
    u8 result = 0;

   
    for (auto &s : node->statements)
    {
        result |=  execute(s.get());
    }



    
    
   exitBlock();



    return result;

}

u8 Compiler::visit_expression_smt(ExpressionStmt *node)
{
    if (node->expression == nullptr)
    {
        throw FatalException("[EXPRESSION STATEMENT] Unknown expression type");
    }
    evaluate(node->expression);

    return 0;
}



u8 Compiler::visit_print_smt(PrintStmt *node)
{
    if (!node) return  0;

    //INFO("[PRINT] %s", node->expression->toString().c_str());
    bool isVar = node->expression->type == ExprType::VARIABLE;

    std::shared_ptr<Expr> result = evaluate(node->expression);
    if (result == nullptr)
    {
        throw FatalException("[PRINT] Unknown expression type");
    }
    if (result->type == ExprType::L_NUMBER)
    {
        NumberLiteral *nl = static_cast<NumberLiteral *>(result.get());
        nl->print();
         
    }
    else if (result->type == ExprType::L_STRING)
    {
        StringLiteral *sl = static_cast<StringLiteral *>(result.get());
        sl->print();
    } else if (result->type == ExprType::LITERAL)
    {
        PRINT("nil");
    } else if (result->type == ExprType::L_STRUCT)
    {
        StructLiteral *sl = static_cast<StructLiteral *>(result.get());
        sl->print();

    } else if (result->type == ExprType::L_ARRAY)
    {
        ArrayLiteral *al = static_cast<ArrayLiteral *>(result.get());
        al->print();
    }
    
    else 
    {
       WARNING("[PRINT] Unknown literal type %s", result->toString().c_str());
    }
  return 0;
}


std::shared_ptr<Expr> Compiler::visit_variable(Variable *node)
{
   // INFO("READ Variable: %s", node->name.lexeme.c_str());
    Environment *environment = currentEnvironment();


    std::shared_ptr<Expr> result = environment->get(node->name.lexeme);
    if (result == nullptr)
    {
        throw FatalException("Undefined variable: '" + node->name.lexeme +"' at line "+ std::to_string(node->name.line ));
    }
    if (result->type == ExprType::LITERAL)
    {
      WARNING("Variable: %s is not initialized", node->name.lexeme.c_str());
    }
    return result;
}

u8 Compiler::visit_declaration(Declaration *node)
{

     
    Environment *environment = currentEnvironment();
   

       

        if (node->is_initialized)
        {


                Token name = node->names[0];
                // if (environment->contains(name.lexeme))
                // {
                //     throw FatalException("Variable already defined: " + name.lexeme +" at line "+ std::to_string(name.line ));
                // }
            std::shared_ptr<Expr>  value = evaluate(node->initializer);
            environment->define(name.lexeme, value);

            for (u32 i = 1; i < node->names.size(); i++)
            {
                    Token name = node->names[i];
                    if (environment->contains(name.lexeme))
                    {
                        throw FatalException("Variable already defined: " + name.lexeme +" at line "+ std::to_string(name.line ));
                    }
                     environment->define(node->names[i].lexeme, value);
                
               
            }
        } else 
        {
            for (u32 i = 0; i < node->names.size(); i++)
            {
                 Token name = node->names[i];
                if (environment->contains(name.lexeme))
                {
                    throw FatalException("Variable already defined: " + name.lexeme +" at line "+ std::to_string(name.line ));
                }
                std::shared_ptr<Literal> value = std::make_shared<Literal>();
                environment->define(name.lexeme, std::move(value));
            }
        }


    return 0;
}

static bool is_truthy(Expr *expr)
{
    if (expr == nullptr)
    {
        return true;
    }
    if (expr->type == ExprType::L_NUMBER)
    {
        NumberLiteral *nl = static_cast<NumberLiteral *>(expr);
        return nl->value != 0;
    }
    if (expr->type == ExprType::L_STRING)
    {
        StringLiteral *sl = static_cast<StringLiteral *>(expr);
        return !sl->value.empty();
    }
    return true;
}

static bool is_equal(Expr *a, Expr *b)
{
    if (a == nullptr && b == nullptr) return true;
    if (a->type != b->type) return false;
    if (a->type == ExprType::L_NUMBER && b->type == ExprType::L_NUMBER)
    {
        NumberLiteral *nl = static_cast<NumberLiteral *>(a);
        NumberLiteral *nl2 = static_cast<NumberLiteral *>(b);
        return nl->value == nl2->value;
    }
    if (a->type == ExprType::L_STRING && b->type == ExprType::L_STRING)
    {
        StringLiteral *sl = static_cast<StringLiteral *>(a);
        StringLiteral *sl2 = static_cast<StringLiteral *>(b);
        return sl->value == sl2->value;
    }
    return true;
}

u8 Compiler::visit_if(IFStmt *node)
{
    std::shared_ptr<Expr> condition = evaluate(node->condition);
    if (condition == nullptr)
    {
        throw FatalException("Invalid condition");
    }
    if (is_truthy(condition.get()))
    {
        return  execute(node->then_branch.get());
    }
    
    for (auto &elif : node->elifBranch)
    {
        if (is_truthy(evaluate(elif->condition).get()))
        {
            return execute(elif->then_branch.get());
        }
    }
    
    if (node->else_branch != nullptr)
    {
        return execute(node->else_branch.get());
    }

    return 0;

}

u8 Compiler::visit_while(WhileStmt *node)
{


    loop_count++;


    while (true)
    {
      
            auto condition = evaluate(node->condition);
            if (!is_truthy(condition.get()))
            {
                break;
            }





    try  
    {

       
            execute(node->body.get());
        
    }
        catch (BreakException &e)
        {
          //  break;
        }

        catch (ContinueException e)
        {
        }
      
    }

    loop_count--;



    return 0;
}


u8 Compiler::visit_do(DoStmt *node)
{
    loop_count++;

    do 
    {
        try 
        {
            execute(node->body.get());
        }
        catch (BreakException &e)
        {
            break;
        }
        catch (ContinueException e)
        {
        }
    } while (is_truthy(evaluate(node->condition).get()));
    loop_count--;


    return 0;
}


u8 Compiler::visit_program(Program *node)
{
    
    for (auto &s : node->statements)
    {
        execute(s.get());
    }
    clear();



    return 0;
}

u8 Compiler::visit_function(FunctionStmt *node)
{
    if (functionMap.find(node->name.lexeme) != functionMap.end())
    {
        throw FatalException("Function '" + node->name.lexeme + "' already defined .");
    }
  
    std::shared_ptr<Function> function =  std::make_shared<Function>();

    functions.push_back(function);

    
    functionMap[node->name.lexeme] = node;


    

    //function->environment = Factory::as().make_environment(global);


    function->name = node->name;
    function->arity = node->args.size();

    for (u32 i = 0; i < node->args.size(); i++)
    {
        function->args[i]=node->args[i];
    }
    function->body = node->body;
    
    
    global->define(function->name.lexeme, function);



    return 0;
}

u8 Compiler::visit_struct(StructStmt *node)
{
  //  PRINT("VISIT Struct: %s", node->name.lexeme.c_str());

    std::shared_ptr<StructLiteral> sl =  std::make_shared<StructLiteral>();
    sl->name = std::move(node->name.lexeme);

     for (u32 i = 0; i < node->fields.size(); i++)
    {
      //  PRINT("Field: %s", node->fields[i].lexeme.c_str());
        std::shared_ptr<Expr> expr = evaluate(node->values[i]);
        sl->members[node->fields[i].lexeme] = std::move(expr);
    }

    
    if (global->define(node->name.lexeme, sl))
    {
        structs.push_back(std::move(sl)); 
    }

     

    return 0;
}

u8 Compiler::visit_class(ClassStmt *node)
{
    return 0;
}

u8 Compiler::visit_array(ArrayStmt *node)
{
    INFO("Visit array: %s", node->name.lexeme.c_str());
    
    std::shared_ptr<ArrayLiteral> al =  std::make_shared<ArrayLiteral>();
    al->name = node->name.lexeme;
    if (global->define(node->name.lexeme, std::move(al)))
    {
        for (u32 i = 0; i < node->values.size(); i++)
        {
            std::shared_ptr<Expr> expr = evaluate(node->values[i]);
            al->values.push_back(std::move(expr));
        }
    }
    return 0;
}

u8 Compiler::visit_map(MapStmt *node)
{
    return 0;
}

u8 Compiler::visit_for(ForStmt *node)
{

     enterBlock();

     execute(node->initializer.get());

    loop_count++;
 

    while (true)
    {
      
            auto condition = evaluate(node->condition);
            if (!is_truthy(condition.get()))
                break;
           

        try 
        {
            execute(node->body.get());
        }
        catch (BreakException &e)
        {
            break;
        }

        catch (ContinueException e)
        {
        }
        

      
         
        evaluate(node->increment);
      }

    loop_count--;
        


    exitBlock();


      while (environmentStack.size() > 1)
    {
        Environment *env = environmentStack.top();
        Factory::as().free_environment(env);
        environmentStack.pop();
    }


    return 0;
}


u8 Compiler::visit_return(ReturnStmt *node)
{
    std::shared_ptr<Expr> value = evaluate(node->value);
    throw ReturnException(value);
    return 3;
}

u8 Compiler::visit_break(BreakStmt *node)
{
    if (loop_count == 0)
    {
       WARNING("BREAK outside of loop");
       return 0;
    }
    throw BreakException("BREAK");
    return 1;
}

u8 Compiler::visit_continue(ContinueStmt *node)
{
    if (loop_count == 0)
    {
       WARNING("CONTINUE outside of loop");
       return 0;
    }
   // Factory::as().free_continue(node);
    throw ContinueException("CONTINUE");
    return 2;
}

u8 Compiler::visit_switch(SwitchStmt *stmt)
{
    if (!stmt)
    {
           throw FatalException("invalid switch expression");
    }

    auto condition = evaluate(stmt->condition);
    if (!condition)
    {
           throw FatalException("invalid switch condition");
    }
 

    for (const auto &caseStmt : stmt->cases)
    {

        auto result = evaluate(caseStmt->condition);
        if (!result)
        {
               throw FatalException("invalid case condition");
        }
      
        if (is_equal(condition.get(), result.get()))
        {
            return execute(caseStmt->body.get());
        }
    }
    if (stmt->defaultBranch != nullptr)
    {
       return  execute(stmt->defaultBranch.get());
    }

    return 0;
}

Compiler::Compiler(Interpreter *i, Compiler *c)
{
    interpreter = i;
    parent = c;
    if (parent != nullptr)
        global = Factory::as().make_environment(parent->global);
    else
        global = Factory::as().make_environment(nullptr);

    environmentStack.push(global);
    

    
}

Compiler::~Compiler()
{
    
}



std::shared_ptr<Expr> Compiler::visit_empty_expression(Expr *node)
{
    WARNING("Empty expression" );
    return std::make_shared<Literal>();
}

std::shared_ptr<Expr> Compiler::visit_binary(BinaryExpr *node)
{
    std::shared_ptr<Expr> left  = evaluate(node->left);
    if (!left) return std::make_shared<EmptyExpr>();
    std::shared_ptr<Expr> right = evaluate(node->right);
    if (!right) return std::make_shared<EmptyExpr>();
    switch (node->op.type)
    {
        case TokenType::GREATER:
        {
            if (left->type == ExprType::L_NUMBER && right->type == ExprType::L_NUMBER)
            {
                NumberLiteral *l = static_cast<NumberLiteral *>(left.get());
                NumberLiteral *r = static_cast<NumberLiteral *>(right.get());
                std::shared_ptr<NumberLiteral> result =  std::make_shared<NumberLiteral>();
                result->value = l->value > r->value ? 1 : 0;
                return result;
            } 

            break;
        }

        case TokenType::GREATER_EQUAL:
        {
            if (left->type == ExprType::L_NUMBER && right->type == ExprType::L_NUMBER)
            {
                NumberLiteral *l = static_cast<NumberLiteral *>(left.get());
                NumberLiteral *r = static_cast<NumberLiteral *>(right.get());
                std::shared_ptr<NumberLiteral> result =  std::make_shared<NumberLiteral>();
                result->value = l->value >= r->value ? 1 : 0;
                return result;
            }

            break;
        }

        case TokenType::LESS:
        {
            if (left->type == ExprType::L_NUMBER && right->type == ExprType::L_NUMBER)
            {
                NumberLiteral *l = static_cast<NumberLiteral *>(left.get());
                NumberLiteral *r = static_cast<NumberLiteral *>(right.get());
                std::shared_ptr<NumberLiteral> result =  std::make_shared<NumberLiteral>();
                result->value = l->value < r->value ? 1 : 0;
                return result;
            }

            break;
        }

        case TokenType::LESS_EQUAL:
        {
            if (left->type == ExprType::L_NUMBER && right->type == ExprType::L_NUMBER)
            {
                NumberLiteral *l = static_cast<NumberLiteral *>(left.get());
                NumberLiteral *r = static_cast<NumberLiteral *>(right.get());
                std::shared_ptr<NumberLiteral> result =  std::make_shared<NumberLiteral>();
                result->value = l->value <= r->value ? 1 : 0;
                return result;
            }

            break;
        }
        case TokenType::PLUS:
        {
            if (left->type == ExprType::L_NUMBER && right->type == ExprType::L_NUMBER)
            {
                NumberLiteral *l = static_cast<NumberLiteral *>(left.get());
                NumberLiteral *r = static_cast<NumberLiteral *>(right.get());
                std::shared_ptr<NumberLiteral> result =  std::make_shared<NumberLiteral>();
                result->value = l->value + r->value;
                return result;
            } else if (left->type == ExprType::L_STRING && right->type == ExprType::L_STRING)
            {
                StringLiteral *l = static_cast<StringLiteral *>(left.get());
                StringLiteral *r = static_cast<StringLiteral *>(right.get());
                std::shared_ptr<StringLiteral> result =  std::make_shared<StringLiteral>();
                result->value = l->value + r->value;
                return result;
            } else if (left->type == ExprType::L_STRING && right->type == ExprType::L_NUMBER)
            {
                StringLiteral *l = static_cast<StringLiteral *>(left.get());
                NumberLiteral *r = static_cast<NumberLiteral *>(right.get());
                std::shared_ptr<StringLiteral> result =  std::make_shared<StringLiteral>();
                result->value = l->value + std::to_string(r->value);

                return result;
            } else if (left->type == ExprType::L_NUMBER && right->type == ExprType::L_STRING)
            {
                NumberLiteral *l = static_cast<NumberLiteral *>(left.get());
                StringLiteral *r = static_cast<StringLiteral *>(right.get());
                std::shared_ptr<StringLiteral> result =  std::make_shared<StringLiteral>();
                result->value = std::to_string(l->value) + r->value;
                return result;
            }
            break;
        }
        case TokenType::MINUS:
        {
            if (left->type == ExprType::L_NUMBER && right->type == ExprType::L_NUMBER)
            {
                NumberLiteral *l = static_cast<NumberLiteral *>(left.get());
                NumberLiteral *r = static_cast<NumberLiteral *>(right.get());
                std::shared_ptr<NumberLiteral> result =  std::make_shared<NumberLiteral>();
                result->value = l->value - r->value;

                return result;
            }
            break;
        }
        case TokenType::SLASH:
        {
            if (left->type == ExprType::L_NUMBER && right->type == ExprType::L_NUMBER)
            {
                NumberLiteral *l = static_cast<NumberLiteral *>(left.get());
                NumberLiteral *r = static_cast<NumberLiteral *>(right.get());
                if (r->value == 0)
                {

                    throw FatalException("Division by zero");
                }
                std::shared_ptr<NumberLiteral> result =  std::make_shared<NumberLiteral>();
                result->value = l->value / r->value;

                return result;
            }
            break;
        }
        case TokenType::STAR:
        {
            if (left->type == ExprType::L_NUMBER && right->type == ExprType::L_NUMBER)
            {
                NumberLiteral *l = static_cast<NumberLiteral *>(left.get());
                NumberLiteral *r = static_cast<NumberLiteral *>(right.get());
                std::shared_ptr<NumberLiteral> result =  std::make_shared<NumberLiteral>();   
                result->value = l->value * r->value;

                return result;
            }
            break;
        }
        case TokenType::MOD:
        {
            if (left->type == ExprType::L_NUMBER && right->type == ExprType::L_NUMBER)
            {
                NumberLiteral *l = static_cast<NumberLiteral *>(left.get());
                NumberLiteral *r = static_cast<NumberLiteral *>(right.get());
                std::shared_ptr<NumberLiteral> result =  std::make_shared<NumberLiteral>();
                result->value =std::fmod(l->value, r->value);
   
                return result;
            }
        }
        case TokenType::BANG_EQUAL:
        {
            if (left->type == ExprType::L_NUMBER && right->type == ExprType::L_NUMBER)
            {
                NumberLiteral *l = static_cast<NumberLiteral *>(left.get());
                NumberLiteral *r = static_cast<NumberLiteral *>(right.get());
                std::shared_ptr<NumberLiteral> result =  std::make_shared<NumberLiteral>();
                result->value = l->value != r->value ? 1 : 0;
   
                return result;
            } else if (left->type == ExprType::L_STRING && right->type == ExprType::L_STRING)
            {
                StringLiteral *l = static_cast<StringLiteral *>(left.get());
                StringLiteral *r = static_cast<StringLiteral *>(right.get());
               std::shared_ptr< NumberLiteral> result =  std::make_shared<NumberLiteral>();
                result->value = l->value != r->value ? 1 : 0;

                return result;
            }
            break;
        }

        case TokenType::EQUAL_EQUAL:
        {
            if (left->type == ExprType::L_NUMBER && right->type == ExprType::L_NUMBER)
            {
                NumberLiteral *l = static_cast<NumberLiteral *>(left.get());
                NumberLiteral *r = static_cast<NumberLiteral *>(right.get());
                std::shared_ptr<NumberLiteral> result =  std::make_shared<NumberLiteral>();
                result->value = l->value == r->value ? 1 : 0;

                return result;
            } else if (left->type == ExprType::L_STRING && right->type == ExprType::L_STRING)
            {
                StringLiteral *l = static_cast<StringLiteral *>(left.get());
                StringLiteral *r = static_cast<StringLiteral *>(right.get());
                std::shared_ptr<NumberLiteral> result =  std::make_shared<NumberLiteral>();
                result->value = l->value == r->value ? 1 : 0;

                return result;
            }
            break;
        }
        case TokenType::PLUS_EQUAL://+=
        {
            if (left->type == ExprType::L_NUMBER && right->type == ExprType::L_NUMBER)
            {
                NumberLiteral *l = static_cast<NumberLiteral *>(left.get());
                NumberLiteral *r = static_cast<NumberLiteral *>(right.get());
                std::shared_ptr<NumberLiteral> result =  std::make_shared<NumberLiteral>();
                result->value = l->value += r->value;

                return result;
            }
            break;
        }
        case TokenType::MINUS_EQUAL:// -=
        {
            if (left->type == ExprType::L_NUMBER && right->type == ExprType::L_NUMBER)
            {
                NumberLiteral *l = static_cast<NumberLiteral *>(left.get());
                NumberLiteral *r = static_cast<NumberLiteral *>(right.get());
                std::shared_ptr<NumberLiteral> result =  std::make_shared<NumberLiteral>();
                

                result->value = l->value -= r->value;

                return result;
            }
            break;
        }
        case TokenType::STAR_EQUAL:// *=
        {
            if (left->type == ExprType::L_NUMBER && right->type == ExprType::L_NUMBER)
            {
                NumberLiteral *l = static_cast<NumberLiteral *>(left.get());
                NumberLiteral *r = static_cast<NumberLiteral *>(right.get());
                std::shared_ptr<NumberLiteral> result =  std::make_shared<NumberLiteral>();
                result->value = l->value *= r->value;

                return result;
            }
            break;
        }
        case TokenType::SLASH_EQUAL:// /=
        {
            if (left->type == ExprType::L_NUMBER && right->type == ExprType::L_NUMBER)
            {
                NumberLiteral *l = static_cast<NumberLiteral *>(left.get());
                NumberLiteral *r = static_cast<NumberLiteral *>(right.get());
                std::shared_ptr<NumberLiteral> result =  std::make_shared<NumberLiteral>();
                result->value = l->value /= r->value;
                if (r->value == 0)
                {
                     throw FatalException("Division by zero");
                }

                return result;
            }
            break;
        }
    }

    interpreter->Error(node->op, "[BINARY] Unknown operator");

    return std::make_shared<EmptyExpr>();
}

std::shared_ptr<Expr> Compiler::visit_unary(UnaryExpr *expr)
{
    std::shared_ptr<Expr> right = evaluate(expr->right);
    if (right == nullptr)
    {
        ERROR("Cannot evaluate right hand side of unary expression: %s", expr->op.lexeme.c_str());
        return std::make_shared<EmptyExpr>();
    }
    switch (expr->op.type)
    {

        case TokenType::MINUS:
        {
            if (right->type == ExprType::L_NUMBER)
            {
                NumberLiteral *num = static_cast<NumberLiteral *>(right.get());   
                std::shared_ptr<NumberLiteral> result =  std::make_shared<NumberLiteral>();
                result->value = -num->value;

                return result;
            }
            break;
        }
        case TokenType::BANG:
        {
            if (right->type == ExprType::L_NUMBER)
            {
                NumberLiteral *num = static_cast<NumberLiteral *>(right.get());
                std::shared_ptr<NumberLiteral> result =  std::make_shared<NumberLiteral>();

 
  
                result->value = (num->value==0) ? 0 : 1;


                return result;
            }
            break;
        }
        case TokenType::INC:
        {
            if (right->type == ExprType::L_NUMBER)
            {
                NumberLiteral *num = static_cast<NumberLiteral *>(right.get());
                std::shared_ptr<NumberLiteral> result =  std::make_shared<NumberLiteral>();

                if (expr->isPrefix)
                {
                    result->value = ++num->value;
                }
                else
                {
                    result->value = num->value;
                    num->value++;
                }
          

                
                return result;
            }
            break;
        }
        case TokenType::DEC:
        {
            if (right->type == ExprType::L_NUMBER)
            {
                NumberLiteral *num = static_cast<NumberLiteral *>(right.get());
                std::shared_ptr<NumberLiteral> result =  std::make_shared<NumberLiteral>();
                if (expr->isPrefix)
                {
                    result->value = --num->value;
                }
                else
                {
                    result->value = num->value;
                    num->value--;
                }
                return result;
            }
            break;
        }
       
    
    }
  
    interpreter->Error(expr->op, "[UNARY] Unknown operator");
   
   return std::make_shared<EmptyExpr>();
}

std::shared_ptr<Expr> Compiler::visit_logical(LogicalExpr *node)
{
    std::shared_ptr<Expr> left = evaluate(node->left);

    if (left->type == ExprType::L_NUMBER)
    {
        NumberLiteral *l = static_cast<NumberLiteral *>(left.get());
       
        if (node->op.type == TokenType::OR)
        {
            if (l->value != 0)
            {
                return left;
            }
        }else  if (node->op.type == TokenType::AND)
        {
            if (l->value == 0)
            {
                return left;
            }
        } else if (node->op.type == TokenType::XOR)
        {
            if (l->value != 0)
            {
                return left;
            }
        } 
    }
    return evaluate(node->right);
}

std::shared_ptr<Expr> Compiler::visit_grouping(GroupingExpr *node)
{
    return evaluate(node->expr);
}

std::shared_ptr<Expr> Compiler::visit_literal(Literal *node)
{
    std::shared_ptr<Literal> result =  std::make_shared<Literal>();
    return result;
}

std::shared_ptr<Expr> Compiler::visit_number_literal(NumberLiteral *node)
{
    std::shared_ptr<NumberLiteral> result =  std::make_shared<NumberLiteral>();
    result->value = node->value;
    return result;
}

std::shared_ptr<Expr> Compiler::visit_string_literal(StringLiteral *node)
{
    std::shared_ptr<StringLiteral> result =  std::make_shared<StringLiteral>();
    result->value = node->value;
    return result;
   
}

Interpreter::~Interpreter()
{


    
}   

Interpreter::Interpreter()
{
    compiler = new Compiler(this);
    context = new Context(this);
   
}

bool Interpreter::compile(const std::string &source)
{
    Lexer lexer;
    lexer.initialize();
    lexer.Load(source);
    std::vector<Token> tokens =  lexer.GetTokens();
    if (tokens.size() == 0)
    {
        return false;
    }

    // for (auto token : tokens)
    // {
    //     INFO("Token: %s" ,token.toString().c_str());
    // }

    std::shared_ptr<Program> program=nullptr;

    try 
    {
        Parser parser;
        parser.Load(tokens);
        program =  parser.parse();
        if (program == nullptr)
        {
            return false;
        }
        compiler->execute(program.get());
        parser.clear();
        
    }
    catch (FatalException e)
    {
        Error(e.what());
        return false;
    }
   
    return false;
}

void Interpreter::clear()
{
    INFO("Interpreter destroyed");
    if (compiler != nullptr)
    {
        compiler->clear();
        delete compiler;
        compiler = nullptr;
    }

    if (context != nullptr)
    {
        delete context;
        context = nullptr;
    }

    nativeFunctions.clear();
   
    INFO("Factory destroyed");
    Factory::as().clear();
}

void Interpreter::registerFunction(const std::string &name, NativeFunction function)
{
    if (nativeFunctions.find(name) != nativeFunctions.end())
    {
        throw FatalException("Native function already defined: " + name);
    }
    std::shared_ptr<Native> native =  std::make_shared<Native>();
    compiler->global->define(name,  std::move(native));
    nativeFunctions[name] = function;
}

bool Interpreter::isnative(const std::string &name)
{
    return nativeFunctions.find(name) != nativeFunctions.end();
}

Literal *Interpreter::CallNativeFunction(const std::string &name, int argc)
{
    auto function = nativeFunctions[name];
    Literal *result = function(context, argc);
    return result;
}

void Interpreter::Error(const Token &token, const std::string &message)
{
    int line = token.line;
    std::string text =message+ " at line: " +std::to_string(line);
    Log(2, text.c_str());
    throw FatalException(text);
}
void Interpreter::Error(const std::string &message)
{
    Log(2, message.c_str());
    throw FatalException(message);
}
void Interpreter::Warning(const Token &token,const std::string &message)
{
    int line = token.line;
    std::string text =message+ " at line: " +std::to_string(line);
    Log(1, text.c_str());
}

void Interpreter::Warning(const std::string &message)
{
   Log(1, message.c_str());
}

void Interpreter::Info(const std::string &message)
{
   Log(0, message.c_str());
}

//***************************************************************************************** */

static u32 env_depth = 0;

Environment::Environment()
{

    parent = nullptr;
    depth = ++env_depth;
}

Environment::Environment(Environment *parent)
{

    depth = ++env_depth;
    this->parent = parent;
 //  INFO("Environment created %d", depth);
}

Environment::~Environment()
{

    m_values.clear();

   // INFO("Environment destroyed %d", depth);
    env_depth--;
}

void Environment::print()
{

    for (auto it = m_values.begin(); it != m_values.end(); it++)
    {
        Expr *l = it->second.get();
        if (l != nullptr)
        {
            INFO("%s: %s", it->first.c_str(), l->toString().c_str());
        }
    }
}

bool Environment::define(const std::string &name, std::shared_ptr<Expr> value)
{
    if (m_values.find(name) != m_values.end())
    {
        return false;
    }
    m_values[name] = value;
    return true;
}

std::shared_ptr<Expr> Environment::get(const std::string &name)
{
    if (m_values.find(name) != m_values.end())
    {
        return m_values[name];
    }
    if (parent != nullptr)
    {
        return parent->get(name);
    }
    return nullptr;
}

bool Environment::set(const std::string &name, std::shared_ptr<Expr> value)
{
    if (m_values.find(name) != m_values.end())
    {
        m_values[name] = value;
        return true;
    }
    if (parent != nullptr)
    {
        return parent->set(name, value);
    }
    return false;
}

bool Environment::contains(const std::string &name)
{
    if (m_values.find(name) != m_values.end())
    {
        return true;
    }
    if (parent != nullptr)
    {
        return parent->contains(name);
    }
    return false;
}

bool Environment::assign(const std::string &name, std::shared_ptr<Expr> value)
{
    std::shared_ptr<Expr> expr = nullptr;
    if (m_values.find(name) != m_values.end())
    {
        expr = m_values[name];
    }else 
    if (parent != nullptr)
    {
        return parent->assign(name, value);
    }

     if (value == nullptr)
    {
        ERROR("Cannot assign variable to undefined value: %s", name.c_str());
        return false;
    }
    if (expr->type == ExprType::LITERAL)
    {
        WARNING("Variable: %s is not initialized", name.c_str());
        return replace(name, value);
    }else 
    if (expr->type == ExprType::L_NUMBER && value->type == ExprType::L_NUMBER)
    {
        NumberLiteral *l = static_cast<NumberLiteral *>(expr.get());
        NumberLiteral *r = static_cast<NumberLiteral *>(value.get());
        l->value = r->value;
        return true;
    } else if (expr->type == ExprType::L_STRING && value->type == ExprType::L_STRING)
    {
        StringLiteral *l = static_cast<StringLiteral *>(expr.get());
        StringLiteral *r = static_cast<StringLiteral *>(value.get());
        l->value = r->value;
        return true;
    }
    

    if (expr->type == ExprType::L_NUMBER && value->type == ExprType::L_STRING)
    {
        ERROR("Cannot assign string to number");
        return false;
    } else if (expr->type == ExprType::L_STRING && value->type == ExprType::L_NUMBER)
    {
        ERROR("Cannot assign number to string");
        return false;
    }
   
    return false;
}

bool Environment::replace(const std::string &name, std::shared_ptr<Expr> value)
{
    if (m_values.find(name) != m_values.end())
    {
        m_values[name] = std::move(value);
        return true;
    }
    if (parent != nullptr)
    {
        return parent->replace(name, std::move(value));
    }
    return false;
}

bool Environment::addInteger(const std::string &name, int value)
{
    std::shared_ptr<NumberLiteral> nl =  std::make_shared<NumberLiteral>();
    nl->value = value;
    return define(name, nl);
}

bool Environment::addDouble(const std::string &name, double value)
{
    std::shared_ptr<NumberLiteral> nl =  std::make_shared<NumberLiteral>();
    nl->value = value;
    return define(name, nl);
}

bool Environment::addString(const std::string &name, std::string value)
{
    std::shared_ptr<StringLiteral> sl =  std::make_shared<StringLiteral>();
    sl->value = value;
    return define(name, sl);
}

bool Environment::addBoolean(const std::string &name, bool value)
{
    std::shared_ptr<NumberLiteral> bl =  std::make_shared<NumberLiteral>();
    bl->value = value ? 1 : 0;
    return define(name, bl);
}

Function::Function():Literal()
{
    type = ExprType::L_FUNCTION;
    body = nullptr;
}

ClassLiteral::ClassLiteral()
{
    type = ExprType::L_CLASS;
    name = "";
}

StructLiteral::StructLiteral()
{
    type = ExprType::L_STRUCT;
    name = "";
}

void StructLiteral::print()
{
        std::string s=name+ " ";
        auto it = members.begin();
        while (it != members.end())
        {
            std::string name = it->first;
            std::string value;
            Expr *expr = it->second.get();
            if (expr->type == ExprType::L_NUMBER)
            {
                NumberLiteral *nl = static_cast<NumberLiteral *>(expr);
                value = std::to_string(nl->value);
            } else if (expr->type == ExprType::L_STRING)
            {
                StringLiteral *sl = static_cast<StringLiteral *>(expr);
                value = sl->value;
            } 
            s  += "("+ name+ ":" + value+")";
            
            it++;
        }
        PRINT("%s", s.c_str());
}

ArrayLiteral::ArrayLiteral()
{
    type = ExprType::L_ARRAY;

}

void ArrayLiteral::print()
{
    std::string str ;
    for (u32 i = 0; i < values.size(); i++)
    {
        if (i > 0)
        {
            str += ", ";
        }
        if (values[i]->type == ExprType::L_NUMBER)
        {
            NumberLiteral *l = static_cast<NumberLiteral *>(values[i].get());
            str +=  std::to_string(l->value);
        } else if (values[i]->type == ExprType::L_STRING)
        {
            StringLiteral *l = static_cast<StringLiteral *>(values[i].get());
            str +=  l->value;
        } else if (values[i]->type == ExprType::L_STRUCT)
        {
             StructLiteral *sl = static_cast<StructLiteral *>(values[i].get());
              
                std::string st= sl->name+ " ";
                auto it = sl->members.begin();
                while (it != sl->members.end())
                {
                    std::string name = it->first;
                    std::string value;
                    Expr *expr = it->second.get();
                    if (expr->type == ExprType::L_NUMBER)
                    {
                        NumberLiteral *nl = static_cast<NumberLiteral *>(expr);
                        value = std::to_string(nl->value);
                    } else if (expr->type == ExprType::L_STRING)
                    {
                        StringLiteral *sl = static_cast<StringLiteral *>(expr);
                        value = sl->value;
                    } 
                    st  += "("+ name+ ":" + value+")";
        
                    it++;

                }
                str+= st;  
                 
        }
    }
    PRINT("Array [%s]", str.c_str());
    
}

MapLiteral::MapLiteral()
{
    type = ExprType::L_MAP;
}

Native::Native()
{
    type = ExprType::L_NATIVE;
}

Context::Context(Interpreter *interpreter)
{
    this->interpreter = interpreter;
}

Context::~Context()
{
    clear();
}

void Context::clear()
{
    literals.clear();
}

long Context::getLong(u8 index)
{
    return static_cast<NumberLiteral *>(literals[index].get())->value;
}

int Context::getInt(u8 index)
{
    return static_cast<NumberLiteral *>(literals[index].get())->value;
}

double Context::getDouble(u8 index)
{
    return static_cast<NumberLiteral *>(literals[index].get())->value;
}

float Context::getFloat(u8 index)
{
    return static_cast<NumberLiteral *>(literals[index].get())->value;
}

std::string Context::getString(u8 index)
{
    return static_cast<StringLiteral *>(literals[index].get())->value;
}

bool Context::getBoolean(u8 index)
{
    return static_cast<NumberLiteral *>(literals[index].get())->value != 0;
}

Literal *Context::asFloat(float value)
{
    std::shared_ptr<NumberLiteral> result =  std::make_shared<NumberLiteral>();
    result->value = static_cast<double>(value);
    values.push_back(std::move(result));
    return result.get();
}

Literal *Context::asDouble(double value)
{
    std::shared_ptr<NumberLiteral> result =  std::make_shared<NumberLiteral>();
    result->value = value;
    values.push_back(std::move(result));
    return result.get();
}

Literal *Context::asInt(int value)
{
    std::shared_ptr<NumberLiteral> result =  std::make_shared<NumberLiteral>();
    result->value = static_cast<double>(value);
    values.push_back(std::move(result));
    return result.get();
}

Literal *Context::asLong(long value)
{
    std::shared_ptr<NumberLiteral> result =  std::make_shared<NumberLiteral>();
    result->value = static_cast<double>(value);
    values.push_back(std::move(result));
    return result.get();
}

Literal *Context::asString(std::string value)
{
    std::shared_ptr<StringLiteral> result =  std::make_shared<StringLiteral>();
    result->value = value;
    values.push_back(std::move(result));
    return result.get();
}

Literal *Context::asBoolean(bool value)
{
    std::shared_ptr<NumberLiteral> result =  std::make_shared<NumberLiteral>();
    result->value = value ? 1 : 0;
    values.push_back(std::move(result));
    return result.get();
}

bool Context::isNumber(u8 index)
{
    if (index >= literals.size())
    {
        return false;
    }
    return literals[index]->type == ExprType::L_NUMBER;
}

bool Context::isString(u8 index)
{
    if (index >= literals.size())
    {
        return false;
    }
    return literals[index]->type == ExprType::L_STRING;
}
