#pragma once

#include "Arena.hpp"
#include "Utils.hpp"
#include "Expr.hpp"
#include "Stmt.hpp"

class Environment;


void *Malloc(u32 size,const char* file, u32 line);
void  Free(void* p,u32 size);

#define ARENA_ALLOC(size)    Malloc(size, __FILE__, __LINE__)
#define ARENA_FREE(mem, size) Free(mem,size)

struct Function;
struct ClassLiteral;
struct StructLiteral;
struct ArrayLiteral;
struct MapLiteral;
struct Native;

class Factory
{
    private:

        BlockArena arena;
        StackArena stack;
        friend void *Malloc(u32 size,const char* file, u32 line);
        friend void Free(void* p,u32 size);

        std::vector<Expr> exprs;
        std::vector<Stmt> stmts;
        
        Factory();
        ~Factory();
    public:
        static Factory &as();
        void clear();
        u32 size() const { return arena.size(); }



    

        Environment *make_environment(Environment *parent);
        void free_environment(Environment *expr);


};