#pragma once 
#include "Token.hpp"


struct Visitor;

enum ExprType
{
    E_NONE,
    EMPTY_EXPR,
    BINARY,
    UNARY,
    GROUPING,
    LITERAL,
    L_NUMBER,
    L_STRING,
    L_FUNCTION,
    L_NATIVE,
    L_CLASS,
    L_STRUCT,
    L_ARRAY,
    L_MAP,
    GET,
    GET_DEF,
    SET,
    VARIABLE,
    ASSIGN,
    LOGICAL,
    CALL,
    NOW,
    E_COUNT
};

class Expr
{
public:
    Expr()  {}
    virtual ~Expr() {}

   

    virtual std::shared_ptr<Expr> accept( Visitor &v) = 0;

    ExprType type{ExprType::E_NONE};

    std::string toString();

    virtual void print() {};
};

class EmptyExpr : public Expr
{
public:
    EmptyExpr() : Expr() { type = ExprType::EMPTY_EXPR; }

    std::shared_ptr<Expr> accept( Visitor &v) override;
};


class BinaryExpr : public Expr
{
public:
    BinaryExpr() : Expr() { type = ExprType::BINARY; }

    std::shared_ptr<Expr> accept( Visitor &v) override;

    std::shared_ptr<Expr> left;
    std::shared_ptr<Expr> right;
    Token op;
};


class UnaryExpr : public Expr
{
public:
    UnaryExpr() : Expr() { type = ExprType::UNARY; }

    std::shared_ptr<Expr>  accept( Visitor &v) override;

    std::shared_ptr<Expr> right;
    Token op;
    bool isPrefix;
};

class GroupingExpr : public Expr
{
public:
    GroupingExpr() : Expr() { type = ExprType::GROUPING; }

    std::shared_ptr<Expr>  accept( Visitor &v) override;

    std::shared_ptr<Expr>  expr;
};

class LogicalExpr : public Expr
{
public:
    LogicalExpr() : Expr() { type = ExprType::LOGICAL; }

    std::shared_ptr<Expr>  accept( Visitor &v) override;

    std::shared_ptr<Expr>  left;
    std::shared_ptr<Expr>  right;
    Token op;
};



class Literal : public Expr
{
public:
    Literal() : Expr() { type = ExprType::LITERAL; }

    std::shared_ptr<Expr> accept( Visitor &v) override;
    virtual ~Literal() { }
    virtual void print() override;
};

class NumberLiteral : public Literal
{
public:
    NumberLiteral() : Literal() { type = ExprType::L_NUMBER; }


    std::shared_ptr<Expr> accept( Visitor &v) override;

    void print() override;

    double value;
};




class StringLiteral : public Literal
{
public:
    StringLiteral() : Literal() { type = ExprType::L_STRING; }
 
    std::shared_ptr<Expr> accept( Visitor &v) override;

    void print() override;

    std::string value;
};

class NowExpr : public Expr
{
public:
    NowExpr() : Expr() { type = ExprType::NOW; }
    std::shared_ptr<Expr> accept( Visitor &v) override;

};




class Variable : public Expr
{
public:
    Variable() : Expr() { type = ExprType::VARIABLE; }
    std::shared_ptr<Expr> accept( Visitor &v) override;

    Token name;
};

class Assign : public Expr
{
public:
    Assign() : Expr() { type = ExprType::ASSIGN; }
    std::shared_ptr<Expr> accept( Visitor &v) override;

    Token name;   
    std::shared_ptr<Expr> value;
};

class CallExpr : public Expr
{
public:
    CallExpr() : Expr() { type = ExprType::CALL; }
    std::shared_ptr<Expr> accept( Visitor &v) override;
    Token name;
    std::shared_ptr<Expr> callee;
    std::vector<std::shared_ptr<Expr>> args;

};


class GetExpr : public Expr
{
public:
    GetExpr() : Expr() { type = ExprType::GET; }
    std::shared_ptr<Expr> accept( Visitor &v) override;
    Token name;
    std::shared_ptr<Expr> object;

};

class GetDefinitionExpr : public Expr
{
public:
    GetDefinitionExpr() : Expr() { type = ExprType::GET_DEF; }
    std::shared_ptr<Expr> accept( Visitor &v) override;
    Token name;
    std::shared_ptr<Expr> variable;
    std::vector<std::shared_ptr<Expr>> values;
};


class SetExpr : public Expr
{
public:
    SetExpr() : Expr() { type = ExprType::SET; }
    std::shared_ptr<Expr> accept( Visitor &v) override;
    Token name;
    std::shared_ptr<Expr> object;
    std::shared_ptr<Expr> value;
};