#pragma once 
#include <vector>

#include "Config.hpp"

#include "Token.hpp"


struct Visitor;
struct Expr;
class Environment;

enum StmtType
{
    S_NONE = 0,
    BLOCK,
    EXPRESSION,
    DECLARATION,
    IF,
    WHILE,
    FOR,
    DO,
    SWITCH,
    RETURN,
    BREAK,
    CONTINUE,
    PRINT,
    FUNCTION,
    STRUCT,
    CLASS,
    ARRAY,
    MAP,
    PROGRAM,
    S_COUNT,
};

class Stmt
{
public:
    Stmt()  {}
    virtual ~Stmt() {}
    virtual u8 visit( Visitor &v) = 0;

    StmtType type{StmtType::S_NONE};

    std::string toString();
};


class BlockStmt : public Stmt
{
public:
    BlockStmt() : Stmt() { type = StmtType::BLOCK; }



    u8 visit( Visitor &v) override;

    std::vector<std::shared_ptr<Stmt> > statements;
};


class ExpressionStmt : public Stmt
{
public:
    ExpressionStmt() : Stmt() { type = StmtType::EXPRESSION; }

    u8 visit( Visitor &v) override;

    std::shared_ptr<Expr>  expression;
};


struct ElifStmt
{
    std::shared_ptr<Expr>  condition;
    std::shared_ptr<Stmt>  then_branch;
};

class IFStmt : public Stmt
{
public:
    IFStmt();

    u8 visit( Visitor &v) override;

    std::shared_ptr<Expr>  condition;
    std::shared_ptr<Stmt>  then_branch;
    std::shared_ptr<Stmt>  else_branch;

    std::vector<std::shared_ptr<ElifStmt>> elifBranch;

};

struct CaseStmt 
{
    std::shared_ptr<Expr> condition;
    std::shared_ptr<Stmt> body;
};

class SwitchStmt : public Stmt
{
public:
    SwitchStmt() : Stmt() { type = StmtType::SWITCH; }

    u8 visit( Visitor &v) override;

    std::shared_ptr<Expr> condition;
    std::vector<std::shared_ptr<CaseStmt>> cases;
    std::shared_ptr<Stmt> defaultBranch;
};

class WhileStmt : public Stmt
{
public:
    WhileStmt() : Stmt() { type = StmtType::WHILE; }

    u8 visit( Visitor &v) override;

    std::shared_ptr<Expr> condition;
    std::shared_ptr<Stmt> body;

};

class DoStmt : public Stmt
{
public:
    DoStmt() : Stmt() { type = StmtType::DO; }

    u8 visit( Visitor &v) override;

    std::shared_ptr<Expr> condition;
    std::shared_ptr<Stmt> body;
};


class ForStmt : public Stmt
{
public:
    ForStmt() : Stmt() { type = StmtType::FOR; }

    u8 visit( Visitor &v) override;

    std::shared_ptr<Stmt> initializer;
    std::shared_ptr<Expr> condition;
    std::shared_ptr<Expr> increment;
    std::shared_ptr<Stmt> body;
};

class PrintStmt : public Stmt
{
public:
    PrintStmt() : Stmt() { type = StmtType::PRINT; }
    u8 visit( Visitor &v) override;

    std::shared_ptr<Expr> expression;
};

class Declaration : public Stmt
{
public:
    Declaration() : Stmt() { type = StmtType::DECLARATION; }
    u8 visit( Visitor &v) override;
    std::vector<Token> names;
    bool is_initialized = false;
    std::shared_ptr<Expr> initializer;
};

class ReturnStmt : public Stmt
{
public:
    ReturnStmt() : Stmt() { type = StmtType::RETURN; }
    u8 visit( Visitor &v) override;

    std::shared_ptr<Expr> value;

};


class BreakStmt : public Stmt
{
public:
    BreakStmt() : Stmt() { type = StmtType::BREAK; }
    u8 visit( Visitor &v) override;
};


class ContinueStmt : public Stmt
{
public:
    ContinueStmt() : Stmt() { type = StmtType::CONTINUE; }
    u8 visit( Visitor &v) override;
};


class FunctionStmt : public Stmt
{
public:
    FunctionStmt() : Stmt() { type = StmtType::FUNCTION; }
    u8 visit( Visitor &v) override;
    std::vector<std::string> args;
    Token name;
    std::shared_ptr<Stmt> body;

};

class StructStmt : public Stmt
{
public:
    StructStmt() : Stmt() { type = StmtType::STRUCT; }
    u8 visit( Visitor &v) override;
    
    std::vector<Token> fields;
    std::vector<std::shared_ptr<Expr>> values;
    
    Token name;
};

class ClassStmt : public Stmt
{
public:
    ClassStmt() : Stmt() { type = StmtType::CLASS; }
    u8 visit( Visitor &v) override;
    std::vector<std::shared_ptr<Expr>> fields;
    std::vector<std::shared_ptr<FunctionStmt>> methods;
    std::unordered_map<std::string, std::shared_ptr<FunctionStmt>> methodMap;
    std::unordered_map<std::string, std::shared_ptr<Expr>> fieldMap;
    Token name;
};


class ArrayStmt : public Stmt
{
public:
    ArrayStmt() : Stmt() { type = StmtType::ARRAY; }
    u8 visit( Visitor &v) override;
    std::vector<std::shared_ptr<Expr>> values;
    Token name;
};

class MapStmt : public Stmt
{
public:
    MapStmt() : Stmt() { type = StmtType::MAP; }
    u8 visit( Visitor &v) override;
    std::unordered_map<std::string, std::shared_ptr<Expr>> values;
};



class Program : public Stmt
{
public:
    Program() : Stmt() { type = StmtType::PROGRAM; }

    u8 visit( Visitor &v) override;

    std::vector<std::shared_ptr<Stmt>> statements;
};