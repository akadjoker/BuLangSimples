#pragma once
#include <string>
#include <vector>
#include <unordered_map>
#include "Token.hpp"
#include "Expr.hpp"
#include "Stmt.hpp"

class Parser
{
public:
    Parser();
    ~Parser();

    void Load( std::vector<Token> tokens);

    std::shared_ptr<Program>  parse();

    void clear();

private:


    std::vector<Token> tokens;
    int current;
    bool panicMode;
    int countBegins;
    int countEnds ;




    bool match(const std::vector<TokenType> &types);
    bool match(TokenType type);
    Token consume(TokenType type, const std::string &message);
    bool check(TokenType type);
    bool isAtEnd();
    void synchronize();
    Token advance();
    Token peek();
    Token previous();
    Token lookAhead();

    void Error(const Token &token,const std::string &message);
    void Error(const std::string &message);
    void Warning(const Token &token, const std::string &message);


    std::shared_ptr<Expr> expression();
    std::shared_ptr<Expr> equality();
    std::shared_ptr<Expr> comparison();
    std::shared_ptr<Expr>  assignment();
    std::shared_ptr<Expr> term();
    std::shared_ptr<Expr> factor();
    std::shared_ptr<Expr> unary();  
    std::shared_ptr<Expr> primary(); 
    std::shared_ptr<Expr> logical_or();
    std::shared_ptr<Expr> logical_and();
    std::shared_ptr<Expr> logical_xor(); 


    std::shared_ptr<Expr> call(); 
    std::shared_ptr<Expr> function_call(std::shared_ptr<Expr> callee,  Token name );

    void freecalls();


    std::shared_ptr<Expr> now();

    std::shared_ptr<Program> program();

    std::shared_ptr<Stmt> expression_statement();
    std::shared_ptr<Stmt> variable_declaration();
    std::shared_ptr<Stmt> function_declaration();
    std::shared_ptr<Stmt> print_statement();
    std::shared_ptr<Stmt> statement();
    std::shared_ptr<Stmt> declarations();
    std::shared_ptr<Stmt> block();

    std::shared_ptr<Stmt> if_statement();
    std::shared_ptr<Stmt> while_statement();
    std::shared_ptr<Stmt> do_statement();
    std::shared_ptr<Stmt> for_statement();
    std::shared_ptr<Stmt> return_statement();
    std::shared_ptr<Stmt> break_statement();
    std::shared_ptr<Stmt> continue_statement();
    std::shared_ptr<Stmt> switch_statement();
    std::shared_ptr<Stmt> class_declaration();
    std::shared_ptr<Stmt> struct_declaration();

    std::vector<std::shared_ptr<CallExpr>> calls;
};