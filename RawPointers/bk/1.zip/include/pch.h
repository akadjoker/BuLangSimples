#ifndef PCH_H
#define PCH_H

#include <string.h>
#include <stddef.h>
#include <cstddef> // for std::nullptr_t
#include <cstdio>

#include <cstring>
#include <cstdint>
#include <cstdlib>
#include <cstdio>

#include <stdarg.h>


#include <stdexcept>
#include <vector>
#include <unordered_map>
#include <string>
#include <stack>
#include <math.h>

#include <cassert>
#include <time.h>
#include <climits>

#endif // PCH_H
