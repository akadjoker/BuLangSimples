#pragma once 
#include <vector>

#include "Config.hpp"

#include "Token.hpp"


struct Visitor;
struct Expr;

enum StmtType
{
    S_NONE = 0,
    BLOCK,
    EXPRESSION,
    DECLARATION,
    IF,
    WHILE,
    FOR,
    DO,
    RETURN,
    BREAK,
    CONTINUE,
    PRINT,
    PROGRAM,
    S_COUNT,
};

class Stmt
{
public:
    Stmt()  {}
    virtual ~Stmt() {}
    virtual u8 visit( Visitor &v) = 0;

    StmtType type{StmtType::S_NONE};
};


class BlockStmt : public Stmt
{
public:
    BlockStmt() : Stmt() { type = StmtType::BLOCK; }

    ~BlockStmt();

    u8 visit( Visitor &v) override;

    std::vector<Stmt *> statements;
};


class ExpressionStmt : public Stmt
{
public:
    ExpressionStmt() : Stmt() { type = StmtType::EXPRESSION; }

    u8 visit( Visitor &v) override;

    Expr *expression;
};


class IFStmt : public Stmt
{
public:
    IFStmt();

    u8 visit( Visitor &v) override;

    Expr *condition;
    Stmt *then_branch;
    Stmt *else_branch;

};


class WhileStmt : public Stmt
{
public:
    WhileStmt() : Stmt() { type = StmtType::WHILE; }

    u8 visit( Visitor &v) override;

    Expr *condition;
    Stmt *body;

};


class ForStmt : public Stmt
{
public:
    ForStmt() : Stmt() { type = StmtType::FOR; }

    u8 visit( Visitor &v) override;

    Stmt *initializer;
    Expr *condition;
    Expr *increment;
    Stmt *body;
};

class PrintStmt : public Stmt
{
public:
    PrintStmt() : Stmt() { type = StmtType::PRINT; }
    u8 visit( Visitor &v) override;

    Expr *expression;
};

class Declaration : public Stmt
{
public:
    Declaration() : Stmt() { type = StmtType::DECLARATION; }
    u8 visit( Visitor &v) override;

    Token name;
    bool is_initialized = false;
    Expr *initializer;
};

class ReturnStmt : public Stmt
{
public:
    ReturnStmt() : Stmt() { type = StmtType::RETURN; }
    u8 visit( Visitor &v) override;

    Expr *value;

};


class BreakStmt : public Stmt
{
public:
    BreakStmt() : Stmt() { type = StmtType::BREAK; }
    u8 visit( Visitor &v) override;
};


class ContinueStmt : public Stmt
{
public:
    ContinueStmt() : Stmt() { type = StmtType::CONTINUE; }
    u8 visit( Visitor &v) override;
};


class Program : public Stmt
{
public:
    Program() : Stmt() { type = StmtType::PROGRAM; }

    u8 visit( Visitor &v) override;

    std::vector<Stmt *> statements;
};